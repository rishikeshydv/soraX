(* Function to determine if a list is in order *)
  let rec is_ordered lst =
    match lst with
    | [] | [_] -> true
    | x :: y :: rest -> x <= y && is_ordered (y :: rest)
  
  (* Function to skip every n'th element in a list *) 
  let rec skip n lst =
    let rec skip_helper count lst =
      match lst with
      | [] -> []
      | hd :: tl ->
          if count = n then skip_helper 1 tl
          else hd :: skip_helper (count + 1) tl
    in
    skip_helper 1 lst
  
  
  (* Function to get a slice from a list *)
  let slice lst i k =
    let rec slice_helper lst count acc =
      match lst with
      | [] -> acc
      | hd :: tl ->
          if count < i then slice_helper tl (count+1) acc
          else if count >= i && count <= k then slice_helper tl (count+1) (acc @ [hd])
          else acc
    in
    slice_helper lst 0 []
  
  (* Function to check if a list is palindrome *)
  let is_palindrome lst =
    lst = List.rev lst
  
  (* Function to remove consecutive duplicates *)
  let rec remove_consecutive_duplicates lst =
    match lst with
    | [] | [_] -> lst
    | x :: (y :: _ as rest) ->
        if x = y then remove_consecutive_duplicates rest
        else x :: remove_consecutive_duplicates rest
  
               
  (*Implementation of each functions*)
               
  let example_list = [1; 2; 3; 3; 4; 5]
  
  let is_ordered_result = is_ordered example_list 
      
  let skip_result = skip 2 example_list 
    
  let slice_result = slice example_list 1 3 
  
  let palindrome_result = is_palindrome [1; 2; 3; 2; 1] 
  
  let no_duplicates_result = remove_consecutive_duplicates example_list 
  